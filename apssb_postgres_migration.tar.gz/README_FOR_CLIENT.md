# Access to PostgreSQL Migration Package

## What's Included
This package contains everything needed to migrate the `apssb.mdb` Microsoft Access database to PostgreSQL.

### Files Provided:
- `postgres_migration/` folder containing:
  - `schema.sql` - PostgreSQL database structure
  - 69 CSV files - All data from the Access database
  - `import_data.sql` - Script to import all CSV data

## Requirements
- PostgreSQL installed on your system (version 9.6 or higher)
- About 10-20 MB of disk space

## Simple Migration Steps

### Step 1: Create the PostgreSQL Database
Open your terminal/command prompt and run:
```bash
createdb apssb_db
```
(You can change `apssb_db` to any name you prefer)

### Step 2: Import Database Structure
Navigate to the folder containing this package and run:
```bash
psql -d apssb_db -f postgres_migration/schema.sql
```

### Step 3: Import All Data
```bash
cd postgres_migration
psql -d apssb_db -f import_data.sql
```

## Alternative: One-Command Migration
If you're on Linux/Mac, you can run this single command:
```bash
bash quick_migrate.sh
```

## Verification
To verify the migration worked:
```bash
psql -d apssb_db -c "\dt"
```
This will list all 69 tables that were migrated.

## Connection Details
After migration, connect to your database using:
- Host: localhost
- Database: apssb_db
- Port: 5432 (default)
- Username: (your PostgreSQL username)

## Troubleshooting

### If you get permission errors:
```bash
psql -U your_username -d apssb_db -f postgres_migration/schema.sql
```

### If CSV import fails:
Make sure you're in the `postgres_migration` directory when running the import_data.sql script.

### To drop and restart:
```bash
dropdb apssb_db
createdb apssb_db
# Then repeat steps 2 and 3
```

## Support
If you encounter any issues, please provide:
1. The exact error message
2. Your PostgreSQL version: `psql --version`
3. Your operating system