@echo off
REM Quick PostgreSQL Migration Script for Windows

SET DB_NAME=apssb_db

echo ===================================
echo Access to PostgreSQL Quick Migration
echo ===================================
echo.

REM Check if PostgreSQL is in PATH
where psql >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: PostgreSQL is not installed or not in PATH
    echo Please install PostgreSQL and add it to your PATH
    pause
    exit /b 1
)

REM Check if database exists
psql -U postgres -lqt | findstr /i %DB_NAME% >nul
if %ERRORLEVEL% EQU 0 (
    echo Database '%DB_NAME%' already exists.
    set /p DROP="Do you want to drop and recreate it? (y/N): "
    if /i "%DROP%"=="y" (
        echo Dropping existing database...
        dropdb -U postgres %DB_NAME%
    ) else (
        echo Exiting. Please use a different database name.
        pause
        exit /b 1
    )
)

REM Create database
echo Creating database '%DB_NAME%'...
createdb -U postgres %DB_NAME%

REM Import schema
echo Importing database schema...
psql -U postgres -d %DB_NAME% -f postgres_migration\schema.sql

REM Import data
echo Importing data (this may take a few minutes)...
cd postgres_migration
psql -U postgres -d %DB_NAME% -f import_data.sql
cd ..

REM Show summary
echo.
echo Migration completed successfully!
echo.
echo Database details:
echo - Name: %DB_NAME%
echo - Host: localhost
echo - Port: 5432
echo.
echo To connect: psql -U postgres -d %DB_NAME%
echo.
pause