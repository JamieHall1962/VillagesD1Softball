#!/bin/bash
# Quick PostgreSQL Migration Script

DB_NAME="apssb_db"

echo "==================================="
echo "Access to PostgreSQL Quick Migration"
echo "==================================="
echo ""

# Check if PostgreSQL is installed
if ! command -v psql &> /dev/null; then
    echo "ERROR: PostgreSQL is not installed or not in PATH"
    echo "Please install PostgreSQL first"
    exit 1
fi

# Check if database exists
if psql -lqt | cut -d \| -f 1 | grep -qw "$DB_NAME"; then
    echo "Database '$DB_NAME' already exists."
    read -p "Do you want to drop and recreate it? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "Dropping existing database..."
        dropdb "$DB_NAME"
    else
        echo "Exiting. Please use a different database name."
        exit 1
    fi
fi

# Create database
echo "Creating database '$DB_NAME'..."
createdb "$DB_NAME"

# Import schema
echo "Importing database schema..."
psql -d "$DB_NAME" -f postgres_migration/schema.sql

# Import data
echo "Importing data (this may take a few minutes)..."
cd postgres_migration
psql -d "$DB_NAME" -f import_data.sql
cd ..

# Show summary
echo ""
echo "Migration completed successfully!"
echo ""
echo "Database details:"
echo "- Name: $DB_NAME"
echo "- Tables: $(psql -d "$DB_NAME" -t -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';" | tr -d ' ')"
echo ""
echo "To connect: psql -d $DB_NAME"